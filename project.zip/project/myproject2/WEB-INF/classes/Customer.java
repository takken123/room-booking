import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
public class Customer extends HttpServlet
{
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
{
String price="";
PrintWriter pw=res.getWriter();
pw.println("<html>");
pw.println("<body bgcolor='#DCE775'>");


String s1=req.getParameter("r-no");
String s2=req.getParameter("cname");
String s3=req.getParameter("tname");
String str="select * from room where (room_no=? and catagery=?) and type=?";

Connection con=DBInfo.con;
int flag=0;
try
{
PreparedStatement ps=con.prepareStatement(str);
ps.setString(1,s1);
ps.setString(2,s2);
ps.setString(3,s3);
ResultSet rs=ps.executeQuery();
while(rs.next())
{
flag =1;
price=rs.getString("price");
break;
}
}
catch(Exception e)
{
e.printStackTrace();
}
if(flag==1)
{
pw.println("<center><h1>price is</h1>"+price);
pw.println("<br><br><form action='../book.html'><input type='submit' value='book'></center>");

}
if(flag==0)
{
res.sendRedirect("../customer.html");
}
pw.println("</body></html>");
}
}












