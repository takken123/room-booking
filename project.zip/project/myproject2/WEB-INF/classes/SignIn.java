import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
public class SignIn extends HttpServlet
{
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
{
String utype="";
PrintWriter pw=res.getWriter();
pw.println("<html>");
pw.println("<body bgcolor='pink'>");


String s1=req.getParameter("uname");
String s2=req.getParameter("pass");
String str="select * from signup where username=? and password=?";

Connection con=DBInfo.con;
int flag=0;
try
{
PreparedStatement ps=con.prepareStatement(str);
ps.setString(1,s1);
ps.setString(2,s2);
ResultSet rs=ps.executeQuery();
while(rs.next())
{
flag =1;
utype=rs.getString("username");
break;
}
}
catch(Exception e)
{
e.printStackTrace();
}
if(flag==1)
{

if(utype.equals("sandeep@gmail.com"))
{
res.sendRedirect("../Admin.html");
}
else
{pw.println(utype);
res.sendRedirect("../customer.html");
}
}
if(flag==0)
{
res.sendRedirect("../SignInPage.html");
}
pw.println("</body></html>");
}
}












