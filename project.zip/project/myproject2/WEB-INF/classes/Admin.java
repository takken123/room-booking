import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
public class Admin extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
{
PrintWriter pw=res.getWriter();
pw.println("<html>");
pw.println("<body bgcolor='red'>");
pw.println("<h1>welcome to admin page</h1>");
pw.println("<form action=../LoginDB.html><input type='submit' name='logout'></form>");
pw.println("</body>");
pw.println("</html>");
}
}