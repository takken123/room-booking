import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
public class conform extends HttpServlet
{
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
{
PrintWriter pw=res.getWriter();
pw.println("<html>");

pw.println("<body bgcolor='#DCE775'><center>");
pw.println("<h1>conformation page</h1>");

String s1=req.getParameter("name");
String s2=req.getParameter("mobile");
String s3=req.getParameter("card");
String s4=req.getParameter("pin");
if(s1.equals("")||s2.equals("")||s3.equals("")||s4.equals("")){
pw.println("<h2>fill up all the field!!</h2>");

}
else 
{

pw.println("<h3> ur room is booked mr</h3>"+s1);
}

pw.println("</center></body></html>");
}}