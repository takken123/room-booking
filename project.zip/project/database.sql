/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.0.67-community-nt : Database - project
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`project` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `project`;

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `username` varchar(18) default NULL,
  `password` varchar(18) default NULL,
  `usertype` varchar(18) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`username`,`password`,`usertype`) values ('sandeep','sandeep123','student'),('ram','ram123','student'),('san','san123','student'),('raman','123456','student'),('sujeet','sujeet123','admin'),('dilip','dilip123','admin'),('dilipkumar','dilip',NULL),('sumit','1234',NULL),('sumit','111111',NULL),('sumit','111111',NULL),('sumit','111111',NULL),('sumit','11111',NULL),('sumit','11111',NULL),('sumit','11111',NULL),('sumit','11111',NULL),('sony','sony123',NULL),('sandeep','SAMMM','admin'),('1234','1234','admin'),('sandeep','san23','admin'),('dddd','123','admin'),('san11','san45','admin');

/*Table structure for table `room` */

DROP TABLE IF EXISTS `room`;

CREATE TABLE `room` (
  `room_no` varchar(100) NOT NULL,
  `catagery` char(12) default NULL,
  `type` char(13) default NULL,
  `price` varchar(13) default NULL,
  PRIMARY KEY  (`room_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `room` */

insert  into `room`(`room_no`,`catagery`,`type`,`price`) values ('1','AC','single','1200'),('2','AC','double','2000'),('3','non-ac','single','800'),('4','AC','double','2990'),('5','AC','double','1500');

/*Table structure for table `signup` */

DROP TABLE IF EXISTS `signup`;

CREATE TABLE `signup` (
  `firstname` varchar(30) default NULL,
  `lastname` varchar(30) default NULL,
  `username` varchar(30) default NULL,
  `password` varchar(30) default NULL,
  `confirm` varchar(30) default NULL,
  `mobile` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `signup` */

insert  into `signup`(`firstname`,`lastname`,`username`,`password`,`confirm`,`mobile`) values ('sandeep','sharma','sandeep@gmail.com','san123','san123','7688827178'),('sujeet','sharma','sujeet@gmail.com','sujeet123','sujeet123','9525469909'),('sumit','kumar','sumit@gmail.com','sumit123','sumit123','7485561254'),('raman','kumar','raman@gmail.com','raman','raman','7688827177'),('bishal','kumar','bishal@gmail.com','123','123','796444444'),('raman','kumar','raman@gmail.com','1234','1234','76555552'),('suman','kumar','suman@gmail.com','sum123','sum123','7688827177'),('dilip','kumar','dilip@gmail.com','san','san','9525469909'),('aman','kumar','aman@gmail.com','aman123','aman123','7662114123');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
