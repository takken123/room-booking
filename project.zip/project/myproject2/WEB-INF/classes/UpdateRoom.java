import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
public class UpdateRoom extends HttpServlet
{
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
{
PrintWriter pw=res.getWriter();
pw.println("<html>");
pw.println("<body bgcolor='yellow'><center>");
pw.println("<h1>dopopst method called</h1>");

String s1=req.getParameter("r-no");
String s2=req.getParameter("tname");
String s3=req.getParameter("rname");
String s4=req.getParameter("value");
String str="update room set catagery=?,type=?,price=? where room_no=?";
Connection con=DBInfo.con;
int flag=0;
try
{PreparedStatement ps=con.prepareStatement(str);
ps.setString(1,s2);
ps.setString(2,s3);
ps.setString(3,s4);
ps.setString(4,s1);
flag=ps.executeUpdate();
}
catch(Exception e)
{
e.printStackTrace();
}
if(flag!=0)
{
pw.println("recored update");
pw.println("<a href=../Admin.html>adminpage</a>");
}
if(flag==0)
{
pw.println("retry");
pw.println("<a href=../update.html>RTRY!></a>");
}
pw.println("</center></body></html>");
}
}
