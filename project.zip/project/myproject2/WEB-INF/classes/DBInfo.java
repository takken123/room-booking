import java.sql.*;
public class DBInfo
{
static Connection con;
static 
{
 try
 {
 Class.forName("com.mysql.jdbc.Driver");
 System.out.println("driver loaded");
 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","rat");
 }
 catch(Exception e)
 {
 e.printStackTrace();
 }
 }
 }