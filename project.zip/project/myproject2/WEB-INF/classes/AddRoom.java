import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
public class AddRoom extends HttpServlet
{
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
{
PrintWriter pw=res.getWriter();
pw.println("<html>");
pw.println("<body bgcolor='#DCE775'><center>");
pw.println("<h1>dpopst method called</h1>");

String s1=req.getParameter("r-no");
String s2=req.getParameter("tname");
String s3=req.getParameter("rname");
String s4=req.getParameter("value");
String str="insert into Room(room_no,catagery,type,price) values(?,?,?,?)";
Connection con=DBInfo.con;
int flag=0;
if(s1.equals("")||s2.equals("")||s3.equals("")||s4.equals(""))
{
pw.println("fill all values!!!");
}
else if(s2.equals("select")||s3.equals("select"))
{
pw.println("select both values!! ");
}
else
{
try
{PreparedStatement ps=con.prepareStatement(str);
ps.setString(1,s1);
ps.setString(2,s2);
ps.setString(3,s3);
ps.setString(4,s4);
flag=ps.executeUpdate();
}
catch(Exception e)
{
e.printStackTrace();
}
if(flag!=0)
{
pw.println("recored inserted");
pw.println("<a href=../addroom.html>add other room</a>");
}
if(flag==0)
{
pw.println("retry");
pw.println("<a href=../addroom.html>RTRY!></a>");
}}

pw.println("</center></body></html>");
}
}












