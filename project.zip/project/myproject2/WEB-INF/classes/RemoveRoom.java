import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
public class RemoveRoom extends HttpServlet
{
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
{
PrintWriter pw=res.getWriter();
pw.println("<html>");
pw.println("<body bgcolor='#DCE775'><center>");
pw.println("<h1>dopopst method called</h1>");

String s1=req.getParameter("room_no");


String str="delete from room where room_no=?";
Connection con=DBInfo.con;
int flag=0;
try
{PreparedStatement ps=con.prepareStatement(str);
ps.setString(1,s1);

flag=ps.executeUpdate();
}
catch(Exception e)
{
e.printStackTrace();
}
if(flag!=0)
{
pw.println("recored deleted");
pw.println("<a href=../Admin.html>adminpage</a>");
}
if(flag==0)
{
pw.println("retry");
pw.println("<a href=../remove.html>RTRY!></a>");
}
pw.println("</center></body></html>");
}
}