import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import java.sql.*;
public class SignUp extends HttpServlet
{
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
{String uname="";
PrintWriter pw=res.getWriter();
pw.println("<html>");
pw.println("<head><title>registration page</title></head>");
pw.println("<body bgcolor='#DCE775'><center>");
pw.println("<h1>dopost method called</h1>");
String s1=req.getParameter("fname");
String s2=req.getParameter("lname");
String s3=req.getParameter("uname");
String s4=req.getParameter("pass");
String s5=req.getParameter("cpass");
String s6=req.getParameter("mnum");
if(s1.equals("")||s2.equals("")||s3.equals("")||s4.equals("")||s5.equals("")||s6.equals("")){
pw.println("fill up all the field!!");
}
 else if(s4.equals(s5))
{

String str="insert into signup(firstname,lastname,username,password,confirm,mobile) values(?,?,?,?,?,?)";
Connection con=DBInfo.con;
int flag=0;
try
{PreparedStatement ps=con.prepareStatement(str);
ps.setString(1,s1);
ps.setString(2,s2);
ps.setString(3,s3);
ps.setString(4,s4);
ps.setString(5,s5);
ps.setString(6,s6);

flag=ps.executeUpdate();
}
catch(Exception e)
{
e.printStackTrace();
}
if(flag!=0)
{
pw.println("recored inserted");
pw.println("<a href=../SignInPage.html>login now</a>");
}
if(flag==0)
{
pw.println("registration failed,retry");
pw.println("<a href=../SignUpPage.html>RTRY!></a>");
}
pw.println("</center></body></html>");
}
else
{
pw.println("password not match");
}
}
}











